Hello, here are the instructions for use for these programs:

Everything assumes you have python installed and a environment to run it in.

Filename Murray_Dalton_Lab_01 is the tax/bill calculation program. Simply run it, and go through the steps
which it prints out.

Filename Murray_Dalton_Lab_01_Turtle is the turtle graphics program. If you do not already have turtle
graphics installed, you can install it by running in command prompt `pip install PythonTurtle` or by installing
a version of Python which has it preinstalled. To run it, run it like any other program, and it displays
a visual drawing.

I have neither given nor received unauthorized aid in completing this work, nor have I presented someone else's work as my own.
Dalton Murray