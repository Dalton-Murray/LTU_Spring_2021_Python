Hello, here are the instructions for use for this program:

Everything assumes you have python installed and a environment to run it in.

You must have a input.txt file or an inputs.txt file
Filename Murray_Dalton_Lab_03.py is the Python file you will need to open.

Once the Python file is open, run it, and it should print if it outputted successfully.

I have neither given nor received unauthorized aid in completing this work, nor have I presented someone else's work as my own.
Dalton Murray


