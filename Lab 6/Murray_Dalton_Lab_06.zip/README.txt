I have attached my copy of the words.txt for reference so the progam can work,
as the demo code supplied didn't have the words.txt and had them built in.