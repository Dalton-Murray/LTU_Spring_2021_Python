Hello, here are the instructions for use for these programs:

Everything assumes you have python installed and a environment to run it in.

Filename Murray_Dalton_Lab_02.py is the number guessing game file!

Simply run it and it'll go over the instructions on use!